<?php

print json_decode(rawurldecode($argv[1]))->{'status'};

?>

